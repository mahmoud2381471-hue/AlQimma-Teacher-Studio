package com.alqimma.teacherstudio

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.app.AlertDialog
import android.os.Handler
import android.os.Looper
import android.widget.SeekBar
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.Effects
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.camera.core.Camera
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import java.util.concurrent.TimeUnit
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var recordButton: Button
    private lateinit var flickerButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private var cameraProvider: ProcessCameraProvider? = null
    private var activeCamera: Camera? = null
    private var maxZoomRatio = 1f
    private var minZoomRatio = 1f
    private var exposureMin = 0
    private var exposureMax = 0
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: androidx.camera.video.Recording? = null
    private var frontCamera = false
    private var antibandingMode = android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_50HZ
    private var torchEnabled = false
    private var teacherName = "أ/ محمود عبد العليم حسنى"
    private var lessonTitle = "القمة في الرياضيات والإحصاء"
    private var logoText = "▲ القمة"
    private var logoOpacity = 0.88f
    private var logoScale = 1.0f
    private var logoOnRight = true
    private var showLogo = true
    // none, fade, slide, zoom, bounce, rotate
    private var logoAnimation = "none"
    private var logoAnimationDurationMs = 900L
    private var showLowerThird = true
    private var logoBitmap: Bitmap? = null
    private var selectedQuality: Quality = Quality.FHD
    // 0 means automatic exposure. Manual values are applied only when the camera advertises support.
    private var manualIso: Int = 0
    private var manualExposureNs: Long = 0L
    private var isoRange: android.util.Range<Int>? = null
    private var exposureTimeRange: android.util.Range<Long>? = null
    private val prefs by lazy { getSharedPreferences("alqimma_studio", MODE_PRIVATE) }
    private val uiHandler = Handler(Looper.getMainLooper())
    private var recordingStartedAt = 0L
    private var latestRecordingUri: Uri? = null
    private var pendingSaveFile: File? = null

    // Android Storage Access Framework: lets the teacher choose phone storage,
    // SD card, USB OTG drive, or another document provider for exported MP4 files.
    private val exportDestinationPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { destinationUri ->
        val sourceFile = pendingSaveFile
        pendingSaveFile = null
        if (destinationUri == null) {
            statusText.text = "تم إلغاء اختيار مكان الحفظ؛ النسخة ما زالت داخل مجلد التطبيق"
            return@registerForActivityResult
        }
        if (sourceFile == null || !sourceFile.exists()) {
            statusText.text = "تعذر العثور على ملف الفيديو المؤقت"
            return@registerForActivityResult
        }
        try {
            val output = contentResolver.openOutputStream(destinationUri, "w")
                ?: throw IllegalStateException("تعذر فتح مكان الحفظ المحدد")
            output.use { stream -> sourceFile.inputStream().use { input -> input.copyTo(stream) } }
            statusText.text = "تم حفظ الفيديو في المكان الذي اخترته بنجاح؛ وتظل نسخة العمل داخل التطبيق"
        } catch (error: Exception) {
            // Remove an incomplete destination document so the teacher is not left with a corrupt MP4.
            runCatching { contentResolver.delete(destinationUri, null, null) }
            statusText.text = "تعذر الحفظ في المكان المحدد: ${error.localizedMessage ?: "خطأ في التخزين"}. النسخة الأصلية ما زالت داخل مجلد التطبيق"
        }
    }
    private var isExportingBranding = false
    private val recordingTicker = object : Runnable {
        override fun run() {
            if (recording != null) {
                val elapsed = ((System.currentTimeMillis() - recordingStartedAt) / 1000).toInt()
                val mm = elapsed / 60
                val ss = elapsed % 60
                statusText.text = String.format(Locale.US, "جارٍ التسجيل %02d:%02d", mm, ss)
                uiHandler.postDelayed(this, 1000)
            }
        }
    }

    // Import an existing video from the phone, SD card, or a mounted USB-OTG provider.
    // Persist the read grant so trimming and branding remain available after recreation.
    private val sourceVideoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { /* Some document providers issue a temporary grant only. */ }
            latestRecordingUri = uri
            findViewById<Button>(R.id.trimVideoButton).isEnabled = true
            findViewById<Button>(R.id.exportBrandingButton).isEnabled = true
            statusText.text = "تم اختيار فيديو من الجهاز؛ يمكنك قصه أو إضافة شعار القمة"
        }
    }

    private val logoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val bitmap = BitmapFactory.decodeStream(input)
                    if (bitmap != null) {
                        val target = File(filesDir, "alqimma_logo.png")
                        target.outputStream().use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
                        logoBitmap?.recycle()
                        logoBitmap = bitmap
                        statusText.text = "تم اختيار صورة شعار القمة"
                    } else statusText.text = "تعذر قراءة صورة الشعار"
                }
            } catch (e: Exception) { statusText.text = "تعذر تحميل الشعار: ${e.localizedMessage}" }
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true && result[Manifest.permission.RECORD_AUDIO] == true && (Build.VERSION.SDK_INT >= 29 || result[Manifest.permission.WRITE_EXTERNAL_STORAGE] == true)) startCamera()
        else statusText.text = "يلزم السماح بالكاميرا والميكروفون للتصوير"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        recordButton = findViewById(R.id.recordButton)
        flickerButton = findViewById(R.id.flickerButton)
        val zoomSeek = findViewById<SeekBar>(R.id.zoomSeek)
        val zoomValue = findViewById<TextView>(R.id.zoomValue)
        val exposureSeek = findViewById<SeekBar>(R.id.exposureSeek)
        val exposureValue = findViewById<TextView>(R.id.exposureValue)
        zoomSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ratio = minZoomRatio + (maxZoomRatio - minZoomRatio) * progress / 100f
                if (activeCamera != null) {
                    activeCamera?.cameraControl?.setZoomRatio(ratio)
                    zoomValue.text = String.format(Locale.US, "%.1fx", ratio)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        exposureSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (activeCamera == null || exposureMax <= exposureMin) return
                val index = exposureMin + ((exposureMax - exposureMin) * progress / 100f).toInt()
                activeCamera?.cameraControl?.setExposureCompensationIndex(index)
                exposureValue.text = index.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        cameraExecutor = Executors.newSingleThreadExecutor()
        // Restore the teacher identity and corner watermark between app launches.
        teacherName = prefs.getString("teacher_name", teacherName) ?: teacherName
        lessonTitle = prefs.getString("lesson_title", lessonTitle) ?: lessonTitle
        logoText = prefs.getString("logo_text", logoText) ?: logoText
        logoOpacity = prefs.getFloat("logo_opacity", 0.88f).coerceIn(0.2f, 1f)
        logoScale = prefs.getFloat("logo_scale", 1.0f).coerceIn(0.7f, 1.5f)
        logoOnRight = prefs.getBoolean("logo_on_right", true)
        showLogo = prefs.getBoolean("show_logo", true)
        logoAnimation = prefs.getString("logo_animation", "none") ?: "none"
        logoAnimationDurationMs = prefs.getLong("logo_animation_duration", 900L).coerceIn(300L, 2500L)
        showLowerThird = prefs.getBoolean("show_lower_third", true)
        manualIso = prefs.getInt("manual_iso", 0)
        manualExposureNs = prefs.getLong("manual_exposure_ns", 0L)
        selectedQuality = when (prefs.getString("video_quality", "FHD")) {
            "HD" -> Quality.HD
            "UHD" -> Quality.UHD
            else -> Quality.FHD
        }
        findViewById<Button>(R.id.qualityButton).text = qualityLabel()
        findViewById<Button>(R.id.exportBrandingButton).setOnClickListener { exportWithBranding() }
        findViewById<Button>(R.id.trimVideoButton).setOnClickListener { showTrimDialog() }
        findViewById<Button>(R.id.importVideoButton).setOnClickListener {
            if (recording == null && !isExportingBranding) sourceVideoPicker.launch(arrayOf("video/*"))
        }
        findViewById<Button>(R.id.pickLogoButton).setOnClickListener { logoPicker.launch("image/*") }
        findViewById<Button>(R.id.logoLayoutButton).setOnClickListener { showLogoLayoutDialog() }
        runCatching { File(filesDir, "alqimma_logo.png").takeIf { it.exists() }?.let { logoBitmap = BitmapFactory.decodeFile(it.absolutePath) } }
        findViewById<TextView>(R.id.logoWatermark).text = logoText
        findViewById<TextView>(R.id.logoWatermark).visibility = if (showLogo) android.view.View.VISIBLE else android.view.View.GONE
        findViewById<TextView>(R.id.lowerThirdText).text = "$teacherName  |  $lessonTitle"
        findViewById<TextView>(R.id.lowerThirdText).visibility = if (showLowerThird) android.view.View.VISIBLE else android.view.View.GONE
        applyLogoPreviewAnimation()

        recordButton.setOnClickListener { if (recording == null) startRecording() else stopRecording() }
        flickerButton.setOnClickListener {
            antibandingMode = when (antibandingMode) {
                android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_50HZ -> android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_60HZ
                android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_60HZ -> android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_AUTO
                else -> android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_50HZ
            }
            flickerButton.text = when (antibandingMode) {
                android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_50HZ -> "مقاومة الوميض: 50Hz"
                android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_60HZ -> "مقاومة الوميض: 60Hz"
                else -> "مقاومة الوميض: تلقائي"
            }
            startCamera()
        }
        findViewById<Button>(R.id.torchButton).setOnClickListener {
            val camera = activeCamera ?: return@setOnClickListener
            if (!camera.cameraInfo.hasFlashUnit()) {
                statusText.text = "الفلاش غير متاح في هذه الكاميرا"
                return@setOnClickListener
            }
            torchEnabled = !torchEnabled
            camera.cameraControl.enableTorch(torchEnabled)
            findViewById<Button>(R.id.torchButton).text = if (torchEnabled) "إضاءة: تشغيل" else "إضاءة: إيقاف"
        }
        previewView.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP) {
                val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                    .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                activeCamera?.cameraControl?.startFocusAndMetering(action)
                statusText.text = "تم طلب التركيز وقياس الإضاءة عند موضع اللمس"
                true
            } else true
        }
        findViewById<Button>(R.id.switchCameraButton).setOnClickListener {
            if (recording != null) return@setOnClickListener
            frontCamera = !frontCamera
            startCamera()
        }
        findViewById<Button>(R.id.brandingButton).setOnClickListener { showBrandingDialog() }
        findViewById<Button>(R.id.qualityButton).setOnClickListener { showQualityDialog() }
        findViewById<Button>(R.id.manualCameraButton).setOnClickListener { showManualCameraDialog() }
        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = if (Build.VERSION.SDK_INT <= 28) arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE) else arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) startCamera()
        else permissionLauncher.launch(needed)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get(); cameraProvider = provider
            val previewBuilder = Preview.Builder()
            Camera2Interop.Extender(previewBuilder).setCaptureRequestOption(
                android.hardware.camera2.CaptureRequest.CONTROL_AE_ANTIBANDING_MODE,
                antibandingMode
            )
            applyManualExposure(Camera2Interop.Extender(previewBuilder))
            val preview = previewBuilder.build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val recorderBuilder = Recorder.Builder()
            Camera2Interop.Extender(recorderBuilder).setCaptureRequestOption(
                android.hardware.camera2.CaptureRequest.CONTROL_AE_ANTIBANDING_MODE,
                antibandingMode
            )
            applyManualExposure(Camera2Interop.Extender(recorderBuilder))
            val recorder = recorderBuilder
                .setQualitySelector(QualitySelector.from(selectedQuality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                .build()
            val capture = VideoCapture.withOutput(recorder)
            val selector = if (frontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            try {
                provider.unbindAll()
                activeCamera = provider.bindToLifecycle(this, selector, preview, capture)
                videoCapture = capture
                runCatching {
                    val camera2Info = Camera2CameraInfo.from(activeCamera!!.cameraInfo)
                    isoRange = camera2Info.getCameraCharacteristic(android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                    exposureTimeRange = camera2Info.getCameraCharacteristic(android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                    if (manualIso > 0 && (isoRange == null || manualIso !in isoRange!!)) manualIso = 0
                    if (manualExposureNs > 0L && (exposureTimeRange == null || manualExposureNs !in exposureTimeRange!!)) manualExposureNs = 0L
                }.onFailure {
                    isoRange = null; exposureTimeRange = null; manualIso = 0; manualExposureNs = 0L
                }
                updateManualCameraButton()
                val zoom = activeCamera?.cameraInfo?.zoomState?.value
                minZoomRatio = zoom?.minZoomRatio ?: 1f
                maxZoomRatio = zoom?.maxZoomRatio ?: 1f
                findViewById<SeekBar>(R.id.zoomSeek).isEnabled = maxZoomRatio > minZoomRatio
                findViewById<SeekBar>(R.id.zoomSeek).progress = 0
                findViewById<TextView>(R.id.zoomValue).text = String.format(Locale.US, "%.1fx", minZoomRatio)
                val exposure = activeCamera?.cameraInfo?.exposureState
                exposureMin = exposure?.exposureCompensationRange?.lower ?: 0
                exposureMax = exposure?.exposureCompensationRange?.upper ?: 0
                val exposureBar = findViewById<SeekBar>(R.id.exposureSeek)
                exposureBar.isEnabled = exposureMax > exposureMin
                exposureBar.progress = if (exposureMax > exposureMin) ((0 - exposureMin) * 100 / (exposureMax - exposureMin)).coerceIn(0, 100) else 50
                findViewById<TextView>(R.id.exposureValue).text = "0"
                statusText.text = "جاهز – مقاومة الوميض ${flickerLabel()} (طلب للكاميرا وقد يتجاهله الهاتف)"
                torchEnabled = false
                findViewById<Button>(R.id.torchButton).text = "إضاءة: إيقاف"
            } catch (e: Exception) {
                statusText.text = "تعذر تشغيل الكاميرا: ${e.localizedMessage ?: "خطأ غير معروف"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun flickerLabel(): String = when (antibandingMode) {
        android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_50HZ -> "50Hz"
        android.hardware.camera2.CameraMetadata.CONTROL_AE_ANTIBANDING_MODE_60HZ -> "60Hz"
        else -> "تلقائي"
    }

    private fun startRecording() {
        val capture = videoCapture ?: return
        val name = "AlQimma_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis()) + ".mp4"
        // Record to an app-owned temporary MP4 first. After CameraX finalizes it,
        // ask the teacher to choose the final destination through Android's SAF.
        // The system picker can expose internal storage, SD cards and USB-OTG providers.
        val recordingFile = createExportFile("AlQimma_Recording")
        val output = FileOutputOptions.Builder(recordingFile).build()
        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    flickerButton.isEnabled = false
                    findViewById<Button>(R.id.brandingButton).isEnabled = false
                    findViewById<Button>(R.id.qualityButton).isEnabled = false
                    findViewById<Button>(R.id.torchButton).isEnabled = false
                    recordButton.text = "■ إيقاف التسجيل"
                    findViewById<Button>(R.id.switchCameraButton).isEnabled = false
                    recordingStartedAt = System.currentTimeMillis()
                    uiHandler.removeCallbacks(recordingTicker)
                    uiHandler.post(recordingTicker)
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    uiHandler.removeCallbacks(recordingTicker)
                    if (!event.hasError()) {
                        latestRecordingUri = Uri.fromFile(recordingFile)
                        findViewById<Button>(R.id.trimVideoButton).isEnabled = true
                        findViewById<Button>(R.id.exportBrandingButton).isEnabled = true
                        askTeacherWhereToSave(recordingFile)
                    }
                    recordButton.text = "● بدء التسجيل"
                    recordButton.isEnabled = true
                    findViewById<Button>(R.id.switchCameraButton).isEnabled = true
                    flickerButton.isEnabled = true
                    findViewById<Button>(R.id.brandingButton).isEnabled = true
                    findViewById<Button>(R.id.qualityButton).isEnabled = true
                    findViewById<Button>(R.id.torchButton).isEnabled = true
                    statusText.text = if (!event.hasError()) "اكتمل التسجيل؛ اختر الآن مكان حفظ الفيديو" else "فشل حفظ الفيديو: ${event.error}"
                }
            }
        }
    }


    private fun <T> applyManualExposure(extender: Camera2Interop.Extender<T>) {
        if (manualIso <= 0 || manualExposureNs <= 0L) return
        // Manual sensor controls require AE OFF. Unsupported/ignored keys are handled by the camera HAL.
        extender.setCaptureRequestOption(android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE,
            android.hardware.camera2.CameraMetadata.CONTROL_AE_MODE_OFF)
        extender.setCaptureRequestOption(android.hardware.camera2.CaptureRequest.SENSOR_SENSITIVITY, manualIso)
        extender.setCaptureRequestOption(android.hardware.camera2.CaptureRequest.SENSOR_EXPOSURE_TIME, manualExposureNs)
    }

    private fun updateManualCameraButton() {
        val supported = isoRange != null && exposureTimeRange != null
        findViewById<Button>(R.id.manualCameraButton).text = when {
            !supported -> "إعدادات الغالق وISO: غير مدعومة/غير معروفة"
            manualIso > 0 && manualExposureNs > 0L -> "يدوي: ISO $manualIso | 1/${(1_000_000_000L / manualExposureNs).coerceAtLeast(1)}ث"
            else -> "الغالق وISO: تلقائي"
        }
    }

    private fun showManualCameraDialog() {
        if (recording != null) return
        val rangeIso = isoRange
        val rangeTime = exposureTimeRange
        if (rangeIso == null || rangeTime == null) {
            AlertDialog.Builder(this).setTitle("التحكم اليدوي غير متاح")
                .setMessage("لم تعلن هذه الكاميرا عن نطاقات ISO وسرعة الغالق عبر Android. يمكنك استخدام شريط الإضاءة والتركيز باللمس، أو تجربة الكاميرا الخلفية.")
                .setPositiveButton("حسناً", null).show()
            return
        }
        val isoChoices = listOf(0, 100, 200, 400, 800, 1600).filter { it == 0 || it in rangeIso }
        val timeChoices = listOf(0L, 10_000_000L, 20_000_000L, 33_333_333L, 40_000_000L, 50_000_000L)
            .filter { it == 0L || it in rangeTime }
        val items = isoChoices.map { if (it == 0) "ISO تلقائي" else "ISO $it" } +
            timeChoices.map { if (it == 0L) "سرعة الغالق تلقائية" else "سرعة الغالق 1/${(1_000_000_000L / it).coerceAtLeast(1)} ثانية" }
        val selected = (isoChoices.indexOf(manualIso).takeIf { it >= 0 } ?: 0)
        AlertDialog.Builder(this).setTitle("الغالق و ISO – إعدادات مدعومة")
            .setItems(items.toTypedArray()) { dialog, which ->
                if (which < isoChoices.size) {
                    manualIso = isoChoices[which]
                    if (manualIso == 0) manualExposureNs = 0L
                } else {
                    manualExposureNs = timeChoices[which - isoChoices.size]
                    if (manualExposureNs == 0L) manualIso = 0
                    else if (manualIso == 0) manualIso = isoChoices.firstOrNull { it > 0 } ?: 0
                }
                prefs.edit().putInt("manual_iso", manualIso).putLong("manual_exposure_ns", manualExposureNs).apply()
                updateManualCameraButton()
                dialog.dismiss()
                startCamera()
            }
            .setNeutralButton("إعادة تلقائي") { _, _ ->
                manualIso = 0; manualExposureNs = 0L
                prefs.edit().putInt("manual_iso", 0).putLong("manual_exposure_ns", 0L).apply()
                updateManualCameraButton(); startCamera()
            }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun qualityLabel(): String = when (selectedQuality) {
        Quality.HD -> "جودة الفيديو: HD 720p"
        Quality.UHD -> "جودة الفيديو: UHD 4K"
        else -> "جودة الفيديو: FHD 1080p"
    }

    private fun showQualityDialog() {
        if (recording != null) return
        val labels = arrayOf("HD – 720p (حجم أقل)", "Full HD – 1080p (موصى بها)", "4K – UHD (إذا كانت مدعومة)")
        val values = arrayOf(Quality.HD, Quality.FHD, Quality.UHD)
        val checked = values.indexOf(selectedQuality).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("جودة تسجيل الفيديو")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                selectedQuality = values[which]
                prefs.edit().putString("video_quality", when (selectedQuality) {
                    Quality.HD -> "HD"
                    Quality.UHD -> "UHD"
                    else -> "FHD"
                }).apply()
                findViewById<Button>(R.id.qualityButton).text = qualityLabel()
                dialog.dismiss()
                startCamera()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showBrandingDialog() {
        val logoInput = EditText(this).apply { setText(logoText); hint = "نص شعار الزاوية" }
        val nameInput = EditText(this).apply { setText(teacherName); hint = "اسم المعلم" }
        val titleInput = EditText(this).apply { setText(lessonTitle); hint = "عنوان الدرس" }
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 12, 48, 0)
            addView(logoInput)
            addView(nameInput)
            addView(titleInput)
        }
        AlertDialog.Builder(this)
            .setTitle("هوية الفيديو")
            .setView(container)
            .setPositiveButton("حفظ") { _, _ ->
                logoText = logoInput.text.toString().ifBlank { "▲ القمة" }
                teacherName = nameInput.text.toString().ifBlank { "القمة" }
                lessonTitle = titleInput.text.toString().ifBlank { "درس تعليمي" }
                prefs.edit()
                    .putString("logo_text", logoText)
                    .putString("teacher_name", teacherName)
                    .putString("lesson_title", lessonTitle)
                    .apply()
                findViewById<TextView>(R.id.logoWatermark).text = logoText
        findViewById<TextView>(R.id.logoWatermark).visibility = if (showLogo) android.view.View.VISIBLE else android.view.View.GONE
                findViewById<TextView>(R.id.lowerThirdText).text = "$teacherName  |  $lessonTitle"
        findViewById<TextView>(R.id.lowerThirdText).visibility = if (showLowerThird) android.view.View.VISIBLE else android.view.View.GONE
                statusText.text = "تم حفظ هوية القمة على هذا الهاتف"
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showLogoLayoutDialog() {
        val opacity = SeekBar(this).apply { max = 80; progress = ((logoOpacity - 0.2f) * 100f).toInt().coerceIn(0, 80) }
        val opacityLabel = TextView(this).apply { text = "شفافية الشعار: ${(logoOpacity * 100).toInt()}%"; setTextColor(Color.WHITE) }
        opacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                logoOpacity = (0.2f + progress / 100f).coerceIn(0.2f, 1f)
                opacityLabel.text = "شفافية الشعار: ${(logoOpacity * 100).toInt()}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val sizeLabel = TextView(this).apply { text = "حجم الشعار: ${(logoScale * 100).toInt()}%"; setTextColor(Color.WHITE) }
        val sizeSeek = SeekBar(this).apply { max = 80; progress = ((logoScale - 0.7f) * 100f).toInt().coerceIn(0, 80) }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                logoScale = (0.7f + progress / 100f).coerceIn(0.7f, 1.5f)
                sizeLabel.text = "حجم الشعار: ${(logoScale * 100).toInt()}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val corner = android.widget.RadioGroup(this).apply {
            orientation = android.widget.RadioGroup.HORIZONTAL
            val right = android.widget.RadioButton(this@MainActivity).apply { text = "أعلى اليمين"; id = android.view.View.generateViewId(); isChecked = logoOnRight }
            val left = android.widget.RadioButton(this@MainActivity).apply { text = "أعلى اليسار"; id = android.view.View.generateViewId(); isChecked = !logoOnRight }
            addView(right); addView(left)
            setOnCheckedChangeListener { _, checkedId -> logoOnRight = checkedId == right.id }
        }
        val logoEnabled = android.widget.CheckBox(this).apply { text = "إظهار اللوجو على الفيديو"; setTextColor(Color.WHITE); isChecked = showLogo }
        val animationLabel = TextView(this).apply { text = "حركة اللوجو"; setTextColor(Color.WHITE) }
        val animationOptions = listOf("ثابت بدون حركة", "ظهور تدريجي", "دخول من الجانب", "تكبير تدريجي", "ارتداد خفيف", "دوران عند الظهور")
        val animationValues = listOf("none", "fade", "slide", "zoom", "bounce", "rotate")
        val animationSpinner = android.widget.Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, animationOptions)
            setSelection(animationValues.indexOf(logoAnimation).coerceAtLeast(0))
        }
        val durationLabel = TextView(this).apply { text = "مدة الحركة: ${(logoAnimationDurationMs / 1000f)} ثانية"; setTextColor(Color.WHITE) }
        val durationSeek = SeekBar(this).apply { max = 22; progress = ((logoAnimationDurationMs - 300L) / 100L).toInt().coerceIn(0, 22) }
        durationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                logoAnimationDurationMs = 300L + progress * 100L
                durationLabel.text = "مدة الحركة: ${(logoAnimationDurationMs / 1000f)} ثانية"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val lower = android.widget.CheckBox(this).apply { text = "إظهار شريط اسم المعلم وعنوان الدرس"; setTextColor(Color.WHITE); isChecked = showLowerThird }
        val panel = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 12, 40, 0)
            addView(logoEnabled); addView(animationLabel); addView(animationSpinner); addView(durationLabel); addView(durationSeek); addView(opacityLabel); addView(opacity); addView(sizeLabel); addView(sizeSeek); addView(corner); addView(lower)
            setBackgroundColor(Color.rgb(7, 19, 38))
        }
        AlertDialog.Builder(this).setTitle("موضع وشفافية هوية القمة").setView(panel)
            .setPositiveButton("حفظ") { _, _ ->
                showLogo = logoEnabled.isChecked
                logoAnimation = animationValues[animationSpinner.selectedItemPosition.coerceIn(animationValues.indices)]
                showLowerThird = lower.isChecked
                prefs.edit().putBoolean("show_logo", showLogo).putString("logo_animation", logoAnimation)
                    .putLong("logo_animation_duration", logoAnimationDurationMs).putFloat("logo_opacity", logoOpacity).putFloat("logo_scale", logoScale)
                    .putBoolean("logo_on_right", logoOnRight).putBoolean("show_lower_third", showLowerThird).apply()
                findViewById<TextView>(R.id.logoWatermark).visibility = if (showLogo) android.view.View.VISIBLE else android.view.View.GONE
                findViewById<TextView>(R.id.lowerThirdText).visibility = if (showLowerThird) android.view.View.VISIBLE else android.view.View.GONE
                applyLogoPreviewAnimation()
                statusText.text = "تم حفظ ظهور اللوجو وحركته وموضعه"
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun applyLogoPreviewAnimation() {
        val logoView = findViewById<TextView>(R.id.logoWatermark)
        logoView.animate().cancel()
        logoView.alpha = 1f; logoView.translationX = 0f; logoView.scaleX = 1f; logoView.scaleY = 1f; logoView.rotation = 0f
        if (!showLogo || logoAnimation == "none") return
        val duration = logoAnimationDurationMs
        when (logoAnimation) {
            "fade" -> { logoView.alpha = 0f; logoView.animate().alpha(1f).setDuration(duration).start() }
            "slide" -> { logoView.translationX = if (logoOnRight) 120f else -120f; logoView.animate().translationX(0f).setDuration(duration).start() }
            "zoom" -> { logoView.scaleX = 0.5f; logoView.scaleY = 0.5f; logoView.animate().scaleX(1f).scaleY(1f).setDuration(duration).start() }
            "bounce" -> { logoView.translationY = -35f; logoView.animate().translationY(0f).setDuration(duration).setInterpolator(android.view.animation.BounceInterpolator()).start() }
            "rotate" -> { logoView.rotation = -180f; logoView.animate().rotation(0f).setDuration(duration).start() }
        }
    }

    /** Create a transparent overlay bitmap containing the corner bug and lower-third. */
    private fun createBrandingOverlay(width: Int, height: Int, presentationTimeUs: Long = 0L): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val scale = width / 1280f
        val pad = 24f * scale
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(244, 210, 138); alpha = (logoOpacity * 255).toInt(); textSize = 38f * scale
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB308172D.toInt(); alpha = (logoOpacity * 255).toInt() }
        val lowerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; alpha = (logoOpacity * 255).toInt(); textSize = 28f * scale
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        if (!showLogo && !showLowerThird) return bitmap
        val logo = logoText.ifBlank { "▲ القمة" }
        val lower = "$teacherName  |  $lessonTitle"
        val customLogo = logoBitmap
        val logoImageWidth = if (customLogo != null) 76f * scale * logoScale else 0f
        titlePaint.textSize = 38f * scale * logoScale
        val maxLogoTextWidth = width * 0.62f - pad * 2 - logoImageWidth
        while (titlePaint.textSize > 12f * scale && titlePaint.measureText(logo) > maxLogoTextWidth) titlePaint.textSize *= 0.92f
        val logoWidth = (titlePaint.measureText(logo) + pad * 2 + logoImageWidth).coerceAtMost(width * 0.72f)
        val logoHeight = 78f * scale * logoScale
        val logoLeft = if (logoOnRight) width - logoWidth - pad else pad
        val logoRight = logoLeft + logoWidth
        val durationUs = logoAnimationDurationMs * 1000L
        val progress = (presentationTimeUs.toFloat() / durationUs.toFloat()).coerceIn(0f, 1f)
        val eased = 1f - (1f - progress) * (1f - progress)
        val logoVisible = showLogo
        if (logoVisible) {
            val save = canvas.save()
            val centerX = (logoLeft + logoRight) / 2f
            val centerY = pad + logoHeight / 2f
            var alphaFactor = 1f
            when (logoAnimation) {
                "fade" -> alphaFactor = eased
                "slide" -> canvas.translate(if (logoOnRight) (1f - eased) * width * 0.22f else -(1f - eased) * width * 0.22f, 0f)
                "zoom" -> canvas.scale(0.55f + 0.45f * eased, 0.55f + 0.45f * eased, centerX, centerY)
                "bounce" -> { val bounce = if (progress < 1f) kotlin.math.sin(progress * Math.PI).toFloat() * (1f - progress) * 0.16f else 0f; canvas.translate(0f, -bounce * height) }
                "rotate" -> canvas.rotate((1f - eased) * 360f, centerX, centerY)
            }
            val animatedAlpha = (logoOpacity * alphaFactor * 255).toInt().coerceIn(0, 255)
            titlePaint.alpha = animatedAlpha
            panelPaint.alpha = (0xB3 * alphaFactor).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(logoLeft, pad, logoRight, pad + logoHeight, 12f * scale, 12f * scale, panelPaint)
            if (customLogo != null) {
                val maxLogo = 58f * scale * logoScale
                val ratio = minOf(maxLogo / customLogo.width, maxLogo / customLogo.height)
                val w = customLogo.width * ratio; val h = customLogo.height * ratio
                val imageLeft = if (logoOnRight) logoRight - pad - w - 10f * scale else logoLeft + pad + 10f * scale
                val dst = RectF(imageLeft, pad + (logoHeight - h) / 2f, imageLeft + w, pad + (logoHeight + h) / 2f)
                val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = animatedAlpha }
                canvas.drawBitmap(customLogo, null, dst, imagePaint)
            }
            titlePaint.textAlign = if (logoOnRight) Paint.Align.RIGHT else Paint.Align.LEFT
        val textX = if (logoOnRight) logoRight - pad * 1.7f - logoImageWidth else logoLeft + pad * 1.7f + logoImageWidth
            canvas.drawText(logo, textX, pad + 49f * scale, titlePaint)
            canvas.restoreToCount(save)
        }
        if (showLowerThird) {
            panelPaint.alpha = (logoOpacity * 255).toInt()
            val maxLowerTextWidth = width * 0.84f
            while (lowerPaint.textSize > 12f * scale && lowerPaint.measureText(lower) > maxLowerTextWidth) lowerPaint.textSize *= 0.92f
            val lowerWidth = (lowerPaint.measureText(lower) + pad * 2).coerceAtMost(width * 0.88f)
            val bottom = height - 44f * scale
            canvas.drawRoundRect(width - lowerWidth - pad, bottom - 64f * scale, width - pad, bottom + 8f * scale, 10f * scale, 10f * scale, panelPaint)
            canvas.drawText(lower, width - pad * 1.7f, bottom - 17f * scale, lowerPaint)
        }
        return bitmap
    }


    /** Simple non-destructive clip editor: exports a selected time range as a new MP4. */
    private fun showTrimDialog() {
        val source = latestRecordingUri ?: run { statusText.text = "سجّل فيديو أو اختر فيديو من الجهاز أولاً"; return }
        if (recording != null || isExportingBranding) return
        val retriever = MediaMetadataRetriever()
        val durationMs = try {
            retriever.setDataSource(this, source)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) { 0L } finally { retriever.release() }
        if (durationMs < 2000L) { statusText.text = "تعذر قراءة مدة الفيديو"; return }
        val startInput = EditText(this).apply {
            hint = "بداية القص بالثواني (0)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("0")
        }
        val endInput = EditText(this).apply {
            hint = "نهاية القص بالثواني (${durationMs / 1000})"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText((durationMs / 1000.0).toString().trimEnd('0').trimEnd('.'))
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(startInput)
            addView(endInput)
            addView(TextView(this@MainActivity).apply {
                text = "المدة الكاملة: ${durationMs / 1000} ثانية. سيُحفظ مقطع جديد دون المساس بالأصل."
                setTextColor(Color.DKGRAY)
            })
        }
        AlertDialog.Builder(this).setTitle("قص الفيديو")
            .setView(box)
            .setPositiveButton("تصدير المقطع", null)
            .setNegativeButton("إلغاء", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val startSec = startInput.text.toString().toDoubleOrNull() ?: 0.0
                        val endSec = endInput.text.toString().toDoubleOrNull() ?: durationMs / 1000.0
                        val startMs = (startSec * 1000).toLong()
                        val endMs = (endSec * 1000).toLong()
                        if (startMs < 0 || endMs > durationMs || endMs - startMs < 1000) {
                            endInput.error = "اختر نطاقاً صحيحاً لا يقل عن ثانية"; return@setOnClickListener
                        }
                        dialog.dismiss()
                        exportTrimmedClip(source, startMs, endMs)
                    }
                }
                dialog.show()
            }
    }

    /** Use app-specific Movies storage when available, otherwise fall back to internal files. */
    private fun createExportFile(prefix: String): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val externalMovies = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
        val directory = (externalMovies ?: File(filesDir, "Movies")).apply { mkdirs() }
        return File(directory, "${prefix}_${stamp}.mp4")
    }

    /** Publish a completed MP4 to the public Movies collection without leaving partial entries. */
    private fun publishVideoToGallery(file: File): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AlQimmaTeacherStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val output = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("تعذر فتح ملف المعرض")
            output.use { stream -> file.inputStream().use { input -> input.copyTo(stream) } }
            if (Build.VERSION.SDK_INT >= 29) {
                val ready = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, ready, null, null)
            }
            true
        } catch (error: Exception) {
            runCatching { contentResolver.delete(uri, null, null) }
            throw error
        }
    }

    /** Open Android's system save dialog. Removable USB/SD locations appear when mounted and supported by Android. */
    private fun askTeacherWhereToSave(file: File) {
        if (!file.exists()) {
            statusText.text = "لم يتم العثور على ملف الفيديو الناتج"
            return
        }
        pendingSaveFile = file
        exportDestinationPicker.launch(file.name)
    }

    private fun exportTrimmedClip(source: Uri, startMs: Long, endMs: Long) {
        val button = findViewById<Button>(R.id.trimVideoButton)
        button.isEnabled = false
        statusText.text = "جارٍ قص الفيديو وتصدير نسخة جديدة…"
        val output = createExportFile("AlQimma_Trim")
        try {
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs).setEndPositionMs(endMs).build()
            val item = MediaItem.Builder().setUri(source).setClippingConfiguration(clipping).build()
            val edited = EditedMediaItem.Builder(item).build()
            val transformer = Transformer.Builder(this).addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        button.isEnabled = true
                        try {
                            askTeacherWhereToSave(output)
                        } catch (e: Exception) { statusText.text = "تم القص داخل مجلد التطبيق، لكن تعذر النسخ للمعرض: ${e.localizedMessage}" }
                    }
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    runOnUiThread { button.isEnabled = true; statusText.text = "فشل قص الفيديو: ${exportException.localizedMessage}" }
                }
            }).build()
            transformer.start(edited, output.absolutePath)
        } catch (e: Exception) {
            button.isEnabled = true
            statusText.text = "تعذر بدء القص: ${e.localizedMessage}"
        }
    }

    /** Export a second MP4 with the logo and lower-third permanently composited into every frame. */
    private fun exportWithBranding() {
        val source = latestRecordingUri ?: run {
            statusText.text = "سجّل فيديو أو اختر فيديو من الجهاز أولاً"; return
        }
        if (isExportingBranding) return
        isExportingBranding = true
        val exportButton = findViewById<Button>(R.id.exportBrandingButton)
        exportButton.isEnabled = false
        statusText.text = "جارٍ تجهيز فيديو بشعار القمة…"
        try {
            val retriever = MediaMetadataRetriever()
            val (width, height) = try {
                retriever.setDataSource(this, source)
                var w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
                var h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rotation == 90 || rotation == 270) { val t = w; w = h; h = t }
                Pair(w.coerceAtLeast(2), h.coerceAtLeast(2))
            } finally { retriever.release() }
            val animatedOverlay = object : BitmapOverlay() {
                override fun getBitmap(presentationTimeUs: Long): Bitmap {
                    return createBrandingOverlay(width, height, presentationTimeUs)
                }
            }
            val bitmapOverlay = animatedOverlay
            val effects = Effects(emptyList(), listOf(OverlayEffect(listOf(bitmapOverlay))))
            val edited = EditedMediaItem.Builder(MediaItem.fromUri(source)).setEffects(effects).build()
            val output = createExportFile("AlQimma_Branded")
            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        runOnUiThread {
                            isExportingBranding = false
                            exportButton.isEnabled = true
                            askTeacherWhereToSave(output)
                            android.widget.Toast.makeText(this@MainActivity, "انتهى تصدير فيديو القمة", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                    override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                        runOnUiThread {
                            isExportingBranding = false
                            exportButton.isEnabled = true
                            statusText.text = "تعذر دمج الهوية: ${exportException.localizedMessage ?: "خطأ تصدير"}"
                        }
                    }
                }).build()
            transformer.start(edited, output.absolutePath)
        } catch (e: Exception) {
            isExportingBranding = false
            exportButton.isEnabled = true
            statusText.text = "تعذر بدء دمج الهوية: ${e.localizedMessage ?: "خطأ"}"
        }
    }

    private fun stopRecording() {
        recording?.stop()
        statusText.text = "جارٍ إنهاء التسجيل وحفظ الفيديو…"
        recordButton.isEnabled = false
    }

    override fun onDestroy() {
        uiHandler.removeCallbacks(recordingTicker); recording?.stop(); cameraProvider?.unbindAll(); cameraExecutor.shutdown(); super.onDestroy()
    }
}
